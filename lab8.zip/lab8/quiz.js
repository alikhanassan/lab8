$(document).ready(function() {
    const question_bank = ["What is the capital of France?", "What is the capital of Germany?", "What is the capital of Italy?", "What is the capital of Spain?", "What is the capital of the United Kingdom?"];
    const answer_bank = ["Paris", "Berlin", "Rome", "Madrid", "London"];
    const choices = [["Paris", "London", "Berlin", "Rome"], ["Berlin", "Paris", "London", "Rome"], ["Rome", "Berlin", "Paris", "London"], ["Madrid", "Berlin", "Rome", "Paris"], ["London", "Berlin", "Rome", "Paris"]];
    let score = 0;

    $.each(question_bank, function(index, value) {
        let question = $(`<div class='question${index}'>`);
        $(".quiz").append(question);
        question.append(`<p class='d'> ${value} </p>`)
        $.each(choices[index], function(index_a, answer) {
            question.append(`<label><input type='radio' name='${index}' value='${answer}'>${answer}</label>`)
        });
    }); 

    $(".btn").on('click', function(){
        $.each(question_bank, function(index, value) {
            const picked = $(`input[name=${index}]`)
            if(picked.prop("checked") == true){
                if(picked.val() == answer_bank[index]){
                    score++;
                }
            }
        })
        $(".quiz").append("<h3 style='margin-top:10px; color: red''>"+ "Result is "+ score + " out of "+ question_bank.length+"</h3>");
    })

})